<?php
/**
 * generates password hash
 *
 * @param string $pw
 * @return string
 */
function generate_pw_hash($pw)
 {
  $salt = random_string(10,'0123456789abcdef');
  $salted_hash = sha1($pw.$salt);
  $hash_with_salt = $salted_hash.$salt;
  return $hash_with_salt;
 }

/**
 * checks password comparing it with the hash
 *
 * @param string $pw
 * @param string $hash
 * @return bool
 */
function is_pw_correct($pw,$hash)
 {
  if(strlen($hash)==50) // salted sha1 hash with salt
   {
    $salted_hash = substr($hash,0,40);
    $salt = substr($hash,40,10);
    if(sha1($pw.$salt)==$salted_hash) return true;
    else return false;
   }
  else return false;
 }

function move_up($item, $section, $table)
 {
  $dbr = Database::$content->prepare("SELECT ".$section.", sequence FROM ".$table." WHERE id=:id LIMIT 1");
  $dbr->bindParam(':id', $item, PDO::PARAM_INT);
  $dbr->execute();
  $data = $dbr->fetch();
  if(isset($data['sequence']))
   {
    if($data['sequence'] > 1)
     {
      Database::$content->beginTransaction();
      $dbr = Database::$content->prepare("UPDATE ".$table." SET sequence=:new_sequence WHERE ".$section."=:section AND sequence=:sequence");
      $dbr->bindParam(':section', $data[$section], PDO::PARAM_STR);
      $dbr->bindValue(':new_sequence', 0, PDO::PARAM_INT);
      $dbr->bindValue(':sequence', $data['sequence']-1, PDO::PARAM_INT);
      $dbr->execute();
      $dbr->bindValue(':new_sequence', $data['sequence']-1, PDO::PARAM_INT);
      $dbr->bindValue(':sequence', $data['sequence'], PDO::PARAM_INT);
      $dbr->execute();
      $dbr->bindValue(':new_sequence', $data['sequence'], PDO::PARAM_INT);
      $dbr->bindValue(':sequence', 0, PDO::PARAM_INT);
      $dbr->execute();
      Database::$content->commit();
     }
    return $data[$section];
   }
  return false;;
 }

function move_down($item, $section, $table)
 {
  $dbr = Database::$content->prepare("SELECT ".$section.", sequence FROM ".$table." WHERE id=:id LIMIT 1");
  $dbr->bindParam(':id', $item, PDO::PARAM_INT);
  $dbr->execute();
  $data = $dbr->fetch();
  if(isset($data['sequence']))
   {
    $dbr = Database::$content->prepare("SELECT sequence FROM ".$table." WHERE ".$section."=:section ORDER BY sequence DESC LIMIT 1");
    $dbr->bindParam(':section', $data[$section], PDO::PARAM_STR);
    $dbr->execute();
    $last = $dbr->fetchColumn();
    if($data['sequence'] < $last)
     {
      Database::$content->beginTransaction();
      $dbr = Database::$content->prepare("UPDATE ".$table." SET sequence=:new_sequence WHERE ".$section."=:section AND sequence=:sequence");
      $dbr->bindParam(':section', $data[$section], PDO::PARAM_STR);
      $dbr->bindValue(':new_sequence', 0, PDO::PARAM_INT);
      $dbr->bindValue(':sequence', $data['sequence']+1, PDO::PARAM_INT);
      $dbr->execute();
      $dbr->bindValue(':new_sequence', $data['sequence']+1, PDO::PARAM_INT);
      $dbr->bindValue(':sequence', $data['sequence'], PDO::PARAM_INT);
      $dbr->execute();
      $dbr->bindValue(':new_sequence', $data['sequence'], PDO::PARAM_INT);
      $dbr->bindValue(':sequence', 0, PDO::PARAM_INT);
      $dbr->execute();
      Database::$content->commit();
     }
    return $data[$section];
   }
  return false;
 }
function token_pass(){
$token_pass=true;
if(!isset($_REQUEST['token_id'])) $token_pass=false;
else
    {
    $token_hash=md5(session_id().TOKEN_SALT);
    if(isset($_REQUEST['token_id'])) $token_id=$_REQUEST['token_id'];
    if($token_id!==$token_hash) $token_pass=false;
    }
return $token_pass;
}

?>
