RiteCMS - http://ritecms.com

***Description***
CMS based on PHP and Sqlite. A fork of PhpSqliteCMS with security update and many more features such as EazyMobile, drop down menu, Pagination in Overview pages, etc.

***Installation***
For installation instructions please refer to the INSTALL document.

***Licence***
This product is distributed under the GPL. Please read through the file
LICENSE for more informations about this license.